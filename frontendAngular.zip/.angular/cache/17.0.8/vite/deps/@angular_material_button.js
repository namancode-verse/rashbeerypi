import {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-XRAOPVDH.js";
import "./chunk-47EKDZOK.js";
import "./chunk-BERDFXJ2.js";
import "./chunk-RRF6PEZD.js";
import "./chunk-IZQA4QFM.js";
import "./chunk-5GE2X5GQ.js";
import "./chunk-3KUQHAFI.js";
import "./chunk-Z6LFH7BS.js";
import "./chunk-PUESSDOV.js";
import "./chunk-FFLIBWXC.js";
import "./chunk-C5B75AWU.js";
import "./chunk-KN6UFG4V.js";
import "./chunk-J5XZNU7V.js";
export {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
