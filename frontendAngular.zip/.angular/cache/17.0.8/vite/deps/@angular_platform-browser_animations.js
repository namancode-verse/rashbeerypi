import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-BERDFXJ2.js";
import "./chunk-RRF6PEZD.js";
import "./chunk-IZQA4QFM.js";
import "./chunk-5GE2X5GQ.js";
import "./chunk-Z6LFH7BS.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-PUESSDOV.js";
import "./chunk-FFLIBWXC.js";
import "./chunk-C5B75AWU.js";
import "./chunk-KN6UFG4V.js";
import "./chunk-J5XZNU7V.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
