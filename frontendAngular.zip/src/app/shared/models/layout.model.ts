export interface LayoutModel {
     sidebar : boolean,
     header : {
          logo : boolean,
          profile : boolean,
          theme: boolean
     },
     footer : boolean
}