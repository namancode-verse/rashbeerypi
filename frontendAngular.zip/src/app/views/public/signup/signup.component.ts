import { Component, ViewEncapsulation } from '@angular/core';

@Component({
     selector: 'app-signup',
     templateUrl: './signup.component.html',
     styleUrls: ['./signup.component.scss'],
     encapsulation: ViewEncapsulation.None
})
export class SignupComponent {
     // prettier-ignore
     constructor(
		
	) {
	}

     ngOnInit() {}
}
